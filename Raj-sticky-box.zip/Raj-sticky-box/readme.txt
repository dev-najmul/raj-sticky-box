=== Raj Sticky Box ===
Contributors: farhanrajnajmul
Tags: elementor, sticky, cards, animation, scroll, widget, timeline, process, steps
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create stunning scroll-animated sticky cards for Elementor. Perfect for showcasing processes, timelines, and features with smooth animations.

== Description ==

**Raj Sticky Box** is a powerful Elementor widget that creates beautiful scroll-triggered animated cards with a stacked card effect. Perfect for showcasing step-by-step processes, timelines, feature highlights, and more.

= Key Features =

* **Scroll-Triggered Animations** - Cards reveal with smooth blur, fade, and scale effects
* **Sticky Positioning** - Cards stay fixed while scrolling for maximum impact
* **Stacked Card Effect** - Shadow layers create beautiful depth behind active cards
* **Unlimited Cards** - Add as many cards as needed with the repeater field
* **Fully Customizable** - Control colors, typography, spacing, shadows, and more
* **Responsive Design** - Looks great on all devices
* **Reset Button** - One-click restore to default styles

= Perfect For =

* How it works sections
* Process timelines
* Service showcases
* Feature highlights
* Step-by-step guides
* Onboarding flows

= Customization Options =

**Card Styling:**
* Background color
* Border radius
* Padding
* Box shadow
* Gap between cards
* Sticky offset

**Typography Controls:**
* Title (font, size, weight, color)
* Description (font, size, weight, color)
* Step number (font, size, weight, color)

**Icon Settings:**
* Icon picker with FontAwesome support
* Icon color and size
* Icon background color
* Icon box size and radius

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/raj-sticky-box/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Open Elementor editor and search for "Raj Sticky Box"
4. Drag the widget to your page and customize!

== Frequently Asked Questions ==

= Does this plugin require Elementor? =

Yes, this plugin is an Elementor widget and requires Elementor (free version) to work.

= Can I add unlimited cards? =

Yes! You can add as many cards as you need using the repeater field.

= Is it responsive? =

Yes, all styling options have responsive controls for desktop, tablet, and mobile. The sticky effect automatically converts to static on mobile devices.

= Can I reset the styles to default? =

Yes, there's a "Reset Styles" button in the Style tab that restores all settings to their defaults.

== Screenshots ==

1. Widget in Elementor panel
2. Card customization options
3. Typography controls
4. Frontend animated result

== Changelog ==

= 1.0.0 =
* Initial release
* Scroll-triggered card animations
* Sticky positioning with offset control
* Stacked card shadow effect
* Full style controls
* Responsive design
* Reset styles button

== Upgrade Notice ==

= 1.0.0 =
Initial release of Raj Sticky Box.
