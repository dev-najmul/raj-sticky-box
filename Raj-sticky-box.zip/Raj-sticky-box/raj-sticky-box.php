<?php
/**
 * Plugin Name: Raj Sticky Box
 * Description: Create stunning scroll-animated sticky cards for Elementor. Perfect for showcasing step-by-step processes, timelines, and feature highlights with smooth reveal animations and a beautiful stacked card effect.
 * Version: 1.0.0
 * Author: Farhan Raj Najmul
 * Author URI: https://farhanrajnajmul.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: raj-sticky-box
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Elementor tested up to: 3.18
 * Elementor Pro tested up to: 3.18
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register widget when Elementor is ready.
 */
add_action( 'elementor/widgets/register', 'rsb_register_raj_sticky_box_widget' );

function rsb_register_raj_sticky_box_widget( $widgets_manager ) {

    // Elementor not loaded – just bail, no error.
    if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
        return;
    }

    // Define widget class only once.
    if ( ! class_exists( 'RSB_Raj_Sticky_Box_Widget' ) ) {

        class RSB_Raj_Sticky_Box_Widget extends \Elementor\Widget_Base {

            public function get_name() {
                return 'rsb_raj_sticky_box';
            }

            public function get_title() {
                return __( 'Raj Sticky Box', 'raj-sticky-box' );
            }

            public function get_icon() {
                return 'eicon-columns';
            }

            public function get_categories() {
                return [ 'general' ];
            }

            /* ------------------ CONTROLS ------------------ */
            protected function register_controls() {

                // CONTENT: Cards
                $this->start_controls_section(
                    'rsb_section_content',
                    [
                        'label' => __( 'Cards', 'raj-sticky-box' ),
                    ]
                );

                $repeater = new \Elementor\Repeater();

                $repeater->add_control(
                    'rsb_step_number',
                    [
                        'label'       => __( 'Step Number', 'raj-sticky-box' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => '01',
                        'label_block' => true,
                    ]
                );

                $repeater->add_control(
                    'rsb_icon',
                    [
                        'label'   => __( 'Icon', 'raj-sticky-box' ),
                        'type'    => \Elementor\Controls_Manager::ICONS,
                        'default' => [
                            'value'   => 'fas fa-search',
                            'library' => 'fa-solid',
                        ],
                    ]
                );

                $repeater->add_control(
                    'rsb_title',
                    [
                        'label'       => __( 'Title', 'raj-sticky-box' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => __( 'Discovery & Strategy', 'raj-sticky-box' ),
                        'label_block' => true,
                    ]
                );

                $repeater->add_control(
                    'rsb_description',
                    [
                        'label'       => __( 'Description', 'raj-sticky-box' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                        'default'     => __( 'We start by understanding your vision, goals, and the content of your project.', 'raj-sticky-box' ),
                        'rows'        => 3,
                        'label_block' => true,
                    ]
                );

                $this->add_control(
                    'rsb_cards',
                    [
                        'label'       => __( 'Cards List', 'raj-sticky-box' ),
                        'type'        => \Elementor\Controls_Manager::REPEATER,
                        'fields'      => $repeater->get_controls(),
                        'default'     => [
                            [
                                'rsb_step_number' => '01',
                                'rsb_title'       => __( 'Discovery & Strategy', 'raj-sticky-box' ),
                                'rsb_description' => __( 'We start by understanding your vision, goals, and the content of your project.', 'raj-sticky-box' ),
                            ],
                            [
                                'rsb_step_number' => '02',
                                'rsb_title'       => __( 'Design & Development', 'raj-sticky-box' ),
                                'rsb_description' => __( 'We translate strategy into clean user experience and robust development.', 'raj-sticky-box' ),
                            ],
                            [
                                'rsb_step_number' => '03',
                                'rsb_title'       => __( 'Launch & Support', 'raj-sticky-box' ),
                                'rsb_description' => __( 'We launch, monitor, and continuously optimize based on real data.', 'raj-sticky-box' ),
                            ],
                        ],
                        'title_field' => '{{{ rsb_step_number }}} — {{{ rsb_title }}}',
                    ]
                );

                // Sticky offset
                $this->add_responsive_control(
                    'rsb_sticky_offset',
                    [
                        'label'      => __( 'Sticky Top Offset', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min' => 0,
                                'max' => 200,
                            ],
                        ],
                        'default'    => [
                            'size' => 90,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-sticky-cards' => 'top: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                // Cards gap
                $this->add_responsive_control(
                    'rsb_cards_gap',
                    [
                        'label'      => __( 'Cards Gap', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        'default'    => [
                            'size' => 28,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-sticky-cards' => 'gap: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Reset Settings */
                $this->start_controls_section(
                    'rsb_section_reset',
                    [
                        'label' => __( 'Reset to Default', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_reset_button',
                    [
                        'type' => \Elementor\Controls_Manager::RAW_HTML,
                        'raw' => '
                        <style>
                            .rsb-reset-styles-btn {
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                gap: 8px;
                                width: 100%;
                                padding: 12px 20px;
                                background: linear-gradient(180deg, #404349 0%, #35383d 100%);
                                color: #e0e1e3;
                                border: 1px solid #4a4d52;
                                border-radius: 3px;
                                cursor: pointer;
                                font-size: 13px;
                                font-weight: 500;
                                font-family: inherit;
                                transition: all 0.2s ease;
                            }
                            .rsb-reset-styles-btn:hover {
                                background: linear-gradient(180deg, #4a4d52 0%, #404349 100%);
                                color: #fff;
                                border-color: #5d6066;
                            }
                            .rsb-reset-styles-btn:active {
                                background: #35383d;
                            }
                            .rsb-reset-styles-btn i {
                                font-size: 14px;
                            }
                            .rsb-reset-note {
                                margin-top: 10px;
                                padding: 8px;
                                background: rgba(255,255,255,0.03);
                                border-radius: 3px;
                                color: #a4a5a8;
                                font-size: 11px;
                                text-align: center;
                                line-height: 1.4;
                            }
                        </style>
                        <button type="button" class="rsb-reset-styles-btn" onclick="rsbResetStyles(event)">
                            <i class="eicon-undo"></i>
                            ' . __( 'Reset Styles', 'raj-sticky-box' ) . '
                        </button>
                        <p class="rsb-reset-note">' . __( 'Restore all style settings to default values', 'raj-sticky-box' ) . '</p>
                        <script>
                        function rsbResetStyles(e) {
                            e.preventDefault();
                            e.stopPropagation();

                            if (!confirm("' . esc_js( __( 'Are you sure you want to reset all styles to default?', 'raj-sticky-box' ) ) . '")) {
                                return;
                            }

                            try {
                                var container = elementor.getContainer(elementor.getPanelView().getCurrentPageView().getOption("editedElementView").getContainer().id);

                                if (!container) {
                                    alert("Could not find widget container");
                                    return;
                                }

                                var settingsToReset = {
                                    "rsb_sticky_offset": {size: 90, unit: "px"},
                                    "rsb_cards_gap": {size: 28, unit: "px"},
                                    "rsb_card_bg_color": "",
                                    "rsb_card_radius": {size: "", unit: "px"},
                                    "rsb_card_padding": {top: "", right: "", bottom: "", left: "", unit: "px", isLinked: false},
                                    "rsb_card_shadow_box_shadow_type": "",
                                    "rsb_card_shadow_box_shadow": "",
                                    "rsb_title_color": "",
                                    "rsb_title_typography_typography": "",
                                    "rsb_title_typography_font_family": "",
                                    "rsb_title_typography_font_size": "",
                                    "rsb_title_typography_font_weight": "",
                                    "rsb_title_typography_text_transform": "",
                                    "rsb_title_typography_font_style": "",
                                    "rsb_title_typography_text_decoration": "",
                                    "rsb_title_typography_line_height": "",
                                    "rsb_title_typography_letter_spacing": "",
                                    "rsb_desc_color": "",
                                    "rsb_desc_typography_typography": "",
                                    "rsb_desc_typography_font_family": "",
                                    "rsb_desc_typography_font_size": "",
                                    "rsb_desc_typography_font_weight": "",
                                    "rsb_desc_typography_text_transform": "",
                                    "rsb_desc_typography_font_style": "",
                                    "rsb_desc_typography_text_decoration": "",
                                    "rsb_desc_typography_line_height": "",
                                    "rsb_desc_typography_letter_spacing": "",
                                    "rsb_number_color": "",
                                    "rsb_number_typography_typography": "",
                                    "rsb_number_typography_font_family": "",
                                    "rsb_number_typography_font_size": "",
                                    "rsb_number_typography_font_weight": "",
                                    "rsb_number_typography_text_transform": "",
                                    "rsb_number_typography_font_style": "",
                                    "rsb_number_typography_text_decoration": "",
                                    "rsb_number_typography_line_height": "",
                                    "rsb_number_typography_letter_spacing": "",
                                    "rsb_icon_color": "",
                                    "rsb_icon_bg_color": "",
                                    "rsb_icon_size": {size: "", unit: "px"},
                                    "rsb_icon_wrap_size": {size: "", unit: "px"},
                                    "rsb_icon_wrap_radius": {size: "", unit: "px"}
                                };

                                $e.run("document/elements/settings", {
                                    container: container,
                                    settings: settingsToReset
                                });

                                elementor.notifications.showToast({
                                    message: "' . esc_js( __( 'Styles reset to default!', 'raj-sticky-box' ) ) . '"
                                });

                            } catch(err) {
                                console.error("RSB Reset Error:", err);
                                alert("Error resetting styles. Please try again.");
                            }
                        }
                        </script>',
                        'content_classes' => 'rsb-reset-control',
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Card */
                $this->start_controls_section(
                    'rsb_section_style_card',
                    [
                        'label' => __( 'Card', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_card_bg_color',
                    [
                        'label'     => __( 'Background Color', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#ffffff',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-card' => 'background-color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'rsb_card_radius',
                    [
                        'label'      => __( 'Border Radius', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range'      => [
                            'px' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 50,
                            ],
                        ],
                        'default'    => [
                            'size' => 24,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-step-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .rsb-step-card.rsb-current::before' => 'border-radius: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .rsb-step-card.rsb-current::after' => 'border-radius: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'rsb_card_padding',
                    [
                        'label'      => __( 'Padding', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', 'em', '%' ],
                        'default'    => [
                            'top'    => 35,
                            'right'  => 40,
                            'bottom' => 35,
                            'left'   => 40,
                            'unit'   => 'px',
                            'isLinked' => false,
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-step-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name'     => 'rsb_card_shadow',
                        'selector' => '{{WRAPPER}} .rsb-step-card',
                        'fields_options' => [
                            'box_shadow_type' => [
                                'default' => 'yes',
                            ],
                            'box_shadow' => [
                                'default' => [
                                    'horizontal' => 0,
                                    'vertical' => 10,
                                    'blur' => 25,
                                    'spread' => 0,
                                    'color' => 'rgba(0,0,0,0.05)',
                                ],
                            ],
                        ],
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Title */
                $this->start_controls_section(
                    'rsb_section_style_title',
                    [
                        'label' => __( 'Title', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_title_color',
                    [
                        'label'     => __( 'Color', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#000000',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-title' => 'color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Typography::get_type(),
                    [
                        'name'     => 'rsb_title_typography',
                        'selector' => '{{WRAPPER}} .rsb-step-title',
                        'fields_options' => [
                            'typography' => [
                                'default' => 'yes',
                            ],
                            'font_size' => [
                                'default' => [
                                    'size' => 20,
                                    'unit' => 'px',
                                ],
                            ],
                        ],
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Description */
                $this->start_controls_section(
                    'rsb_section_style_desc',
                    [
                        'label' => __( 'Description', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_desc_color',
                    [
                        'label'     => __( 'Color', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#666666',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-sub' => 'color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Typography::get_type(),
                    [
                        'name'     => 'rsb_desc_typography',
                        'selector' => '{{WRAPPER}} .rsb-step-sub',
                        'fields_options' => [
                            'typography' => [
                                'default' => 'yes',
                            ],
                            'font_size' => [
                                'default' => [
                                    'size' => 15,
                                    'unit' => 'px',
                                ],
                            ],
                        ],
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Step Number */
                $this->start_controls_section(
                    'rsb_section_style_number',
                    [
                        'label' => __( 'Step Number', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_number_color',
                    [
                        'label'     => __( 'Color', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#e1e1e8',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-number' => 'color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Typography::get_type(),
                    [
                        'name'     => 'rsb_number_typography',
                        'selector' => '{{WRAPPER}} .rsb-step-number',
                        'fields_options' => [
                            'typography' => [
                                'default' => 'yes',
                            ],
                            'font_size' => [
                                'default' => [
                                    'size' => 32,
                                    'unit' => 'px',
                                ],
                            ],
                            'font_weight' => [
                                'default' => '700',
                            ],
                        ],
                    ]
                );

                $this->end_controls_section();

                /* STYLE: Icon */
                $this->start_controls_section(
                    'rsb_section_style_icon',
                    [
                        'label' => __( 'Icon', 'raj-sticky-box' ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );

                $this->add_control(
                    'rsb_icon_color',
                    [
                        'label'     => __( 'Icon Color', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#000000',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-icon'     => 'color: {{VALUE}};',
                            '{{WRAPPER}} .rsb-step-icon svg' => 'fill: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_control(
                    'rsb_icon_bg_color',
                    [
                        'label'     => __( 'Icon Background', 'raj-sticky-box' ),
                        'type'      => \Elementor\Controls_Manager::COLOR,
                        'default'   => '#f1f1f7',
                        'selectors' => [
                            '{{WRAPPER}} .rsb-step-icon-wrap' => 'background-color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'rsb_icon_size',
                    [
                        'label'      => __( 'Icon Size', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min' => 12,
                                'max' => 80,
                            ],
                        ],
                        'default'    => [
                            'size' => 22,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-step-icon'     => 'font-size: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .rsb-step-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'rsb_icon_wrap_size',
                    [
                        'label'      => __( 'Icon Box Size', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range'      => [
                            'px' => [
                                'min' => 30,
                                'max' => 120,
                            ],
                        ],
                        'default'    => [
                            'size' => 48,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-step-icon-wrap' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'rsb_icon_wrap_radius',
                    [
                        'label'      => __( 'Icon Box Radius', 'raj-sticky-box' ),
                        'type'       => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range'      => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 50,
                            ],
                        ],
                        'default'    => [
                            'size' => 16,
                            'unit' => 'px',
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .rsb-step-icon-wrap' => 'border-radius: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );

                $this->end_controls_section();
            }

            /* ------------------ RENDER ------------------ */
            protected function render() {
                $settings  = $this->get_settings_for_display();
                $cards     = ! empty( $settings['rsb_cards'] ) ? $settings['rsb_cards'] : [];
                $widget_id = $this->get_id();

                if ( empty( $cards ) ) {
                    return;
                }
                ?>
                <div class="rsb-sticky-box-wrapper" id="rsb-sticky-box-<?php echo esc_attr( $widget_id ); ?>">
                    <div class="rsb-sticky-cards">
                        <?php foreach ( $cards as $index => $item ) : ?>
                            <div class="rsb-step-card" data-index="<?php echo esc_attr( $index ); ?>">
                                <div class="rsb-step-header">
                                    <div class="rsb-step-icon-wrap">
                                        <span class="rsb-step-icon">
                                            <?php
                                            if ( ! empty( $item['rsb_icon']['value'] ) ) {
                                                \Elementor\Icons_Manager::render_icon(
                                                    $item['rsb_icon'],
                                                    [ 'aria-hidden' => 'true' ]
                                                );
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    <?php if ( ! empty( $item['rsb_step_number'] ) ) : ?>
                                        <span class="rsb-step-number"><?php echo esc_html( $item['rsb_step_number'] ); ?></span>
                                    <?php endif; ?>
                                </div>

                                <?php if ( ! empty( $item['rsb_title'] ) ) : ?>
                                    <h3 class="rsb-step-title"><?php echo esc_html( $item['rsb_title'] ); ?></h3>
                                <?php endif; ?>

                                <?php if ( ! empty( $item['rsb_description'] ) ) : ?>
                                    <p class="rsb-step-sub"><?php echo esc_html( $item['rsb_description'] ); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <style>
                    /* DEFAULT STYLES - using class selectors so Elementor can override */
                    .rsb-sticky-box-wrapper .rsb-sticky-cards {
                        position: sticky;
                        top: 90px;
                        display: flex;
                        flex-direction: column;
                        gap: 28px;
                    }

                    /* Card base styles */
                    .rsb-sticky-box-wrapper .rsb-step-card {
                        position: relative;
                        background: #ffffff;
                        border-radius: 24px;
                        padding: 35px 40px;
                        box-shadow: 0 10px 25px rgba(0,0,0,0.05);

                        /* animation starting state */
                        opacity: 0;
                        transform: translateY(40px) scale(0.96);
                        filter: blur(4px);

                        transition:
                            transform 0.7s cubic-bezier(0.22, 0.61, 0.36, 1),
                            opacity   0.6s ease-out,
                            box-shadow 0.6s ease-out,
                            filter    0.6s ease-out;
                        will-change: transform, opacity, box-shadow, filter;
                    }

                    .rsb-sticky-box-wrapper .rsb-step-card.rsb-active {
                        opacity: 1;
                        transform: translateY(0) scale(1);
                        filter: blur(0);
                    }

                    /* stacked effect on current card */
                    .rsb-sticky-box-wrapper .rsb-step-card.rsb-current::before,
                    .rsb-sticky-box-wrapper .rsb-step-card.rsb-current::after {
                        content:'';
                        position:absolute;
                        left:0;right:0;
                        height:100%;
                        border-radius: inherit;
                        background: inherit;
                        border:1px solid #f3f3f7;
                        box-shadow:0 8px 18px rgba(15,23,42,0.06);
                        z-index:-1;
                        transition: opacity 0.4s ease-out, transform 0.4s ease-out;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-card.rsb-current::before{
                        top:-4px;opacity:.9;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-card.rsb-current::after{
                        top:-8px;opacity:.75;
                    }

                    /* Remove stacked shadow for the last card */
                    .rsb-sticky-box-wrapper .rsb-step-card:last-child.rsb-current::before,
                    .rsb-sticky-box-wrapper .rsb-step-card:last-child.rsb-current::after {
                        display: none !important;
                    }

                    .rsb-sticky-box-wrapper .rsb-step-header{
                        display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-icon-wrap{
                        width:48px;height:48px;background:#f1f1f7;border-radius:16px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-icon-wrap::before{
                        content:'';position:absolute;left:-10px;top:14px;width:40px;height:40px;border-radius:999px;background:#e4e4f0;opacity:.35;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-icon{
                        position:relative;font-size:22px;color:#000000;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-icon svg{
                        width:22px;height:22px;fill:#000000;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-number{
                        font-size:32px;font-weight:700;color:#e1e1e8;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-title{
                        margin:0 0 8px;font-size:20px;color:#000000;
                    }
                    .rsb-sticky-box-wrapper .rsb-step-sub{
                        margin:0;line-height:1.6;font-size:15px;color:#666666;
                    }
                    @media(max-width:900px){
                        .rsb-sticky-box-wrapper .rsb-sticky-cards{position:static;}
                    }
                </style>

                <script>
                    (function () {
                        var c = document.getElementById('rsb-sticky-box-<?php echo esc_js( $widget_id ); ?>');
                        if (!c) return;

                        var cards = Array.prototype.slice.call(
                            c.querySelectorAll('.rsb-step-card')
                        );
                        if (!cards.length) return;

                        function rsbScroll() {
                            // position of the widget in the whole page
                            var sectionTop    = c.offsetTop;
                            var sectionHeight = c.offsetHeight;
                            var scrollY       = window.pageYOffset || document.documentElement.scrollTop || 0;

                            // scroll progress through this section (0–1)
                            var progress = (scrollY - sectionTop) / sectionHeight;
                            if (progress < 0) progress = 0;
                            if (progress > 1) progress = 1;

                            var stepDelta = 0.05; // 5% per card
                            var last      = -1;

                            cards.forEach(function (card, i) {
                                if (progress >= stepDelta * i) {
                                    card.classList.add('rsb-active');
                                    last = i;
                                } else {
                                    card.classList.remove('rsb-active');
                                }
                            });

                            // always keep at least the first card visible once we reach the section
                            if (last === -1 && cards.length) {
                                cards[0].classList.add('rsb-active');
                                last = 0;
                            }

                            cards.forEach(function (card, i) {
                                card.classList.toggle('rsb-current', i === last);
                            });
                        }

                        window.addEventListener('scroll', rsbScroll, { passive: true });
                        window.addEventListener('resize', rsbScroll);
                        rsbScroll();
                    })();
                </script>
                <?php
            }
        }
    }

    // Finally, register our widget instance with Elementor.
    $widgets_manager->register( new \RSB_Raj_Sticky_Box_Widget() );
}
